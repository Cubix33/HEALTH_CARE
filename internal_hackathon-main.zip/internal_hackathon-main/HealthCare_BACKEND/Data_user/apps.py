from django.apps import AppConfig


class DataUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Data_user'
