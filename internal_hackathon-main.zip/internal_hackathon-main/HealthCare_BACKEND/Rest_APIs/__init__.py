default_app_config = 'Rest_APIs.apps.RestApisConfig'  # Replace 'your_app' with your app's name
